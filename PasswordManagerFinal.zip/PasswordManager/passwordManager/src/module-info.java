/**
 * 
 */
/**
 * 
 */
module passwordManager {
	requires java.desktop;
	requires java.sql;
	requires jbcrypt;
}